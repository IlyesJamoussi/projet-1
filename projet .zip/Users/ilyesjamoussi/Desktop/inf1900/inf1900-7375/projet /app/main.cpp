#include "robot.h"

int main() {

    Robot pathFinder;
    pathFinder.start();

    return 0;
}


